
var MENU_ITEMS=[

            
            ["Complaints",null,
                 ["View","./comveiw.jsp"],
                 ["Update","./cid.jsp"],
          ],
          
            //["Cautions","./pcaut.jsp"],
            ["Records",null,
                     ["Add","./uptheif.html"],
                     ["View","./listrecords"],
                     ["Status","./recordup.jsp"],
             ],
             ["Messages",null,
                     ["Send",null,
                     ["Admin","./adminmsg.html"],
                     ["Department","./cmesg.jsp"],
                     ],      
                     ["View",null,
                     ["Admin","./pcaut.jsp"],
                     ["Department","./viewmsgs.jsp"],
                     ["Feedback","./viewfeed.jsp"],
                     ],
                     
             ],
          ["Logout","./logout.jsp"], 
];