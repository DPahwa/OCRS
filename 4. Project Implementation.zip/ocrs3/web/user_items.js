//Code of menu_items.js file
var MENU_ITEMS=[

           ["Home","./userpage.jsp"],


           ["Complaints",null,
                 ["Give Complaint","./com.jsp"],
                 ["View Status","./viewstatus.html"],
                	 
            ],
            ["Criminals","./viewrecords.jsp"],
                    
            //["Feedback","./feedback.jsp"],
            
            ["Logout","./logout.jsp"],
                       


];