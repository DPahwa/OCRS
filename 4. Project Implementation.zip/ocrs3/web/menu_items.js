//Code of menu_items.js file
var MENU_ITEMS=[

           
           ["Home","./home1.html"],

           ["Login",null,
                 ["People","./user.html"],
                 ["Police Department","./policelogin.jsp"],
                 [" Admin","./adminlogin.html"],
                  
            ],
            ["Alerts","./viewalerts.jsp"],
        
            ["Contact Us",null,
                    ["Stations","./contactus.jsp"],
                    ["Officers","./officers.html"],
                   
                   
                   
             ],



];