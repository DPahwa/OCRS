//Code of menu_items.js file
var MENU_ITEMS=[

            
            ["Complaints",null,
                 ["View","./adcom.jsp"],
                 
            ],
           ["Accounts",null,
                 ["Civilian","./civilacc.jsp"],
                 ["Department",null,
                    ["Add","./poladd.jsp"],
                    ["Remove","./polacc.jsp"],
                 ],
               
           ],
            ["Messages",null,
                  ["Send","./adcau.jsp"],
                  ["View","./deptmsgs.jsp"],
            ],
                        
             
          ["Logout","./logout.jsp"], 
];